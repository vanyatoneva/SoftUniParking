﻿namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person p1 = new Person();
            Person p2 = new Person(25);
            Person p3 = new Person("Sasho", 15);

            p1.Name = "Pesho";
            p1.Age = 20;
            p2.Name = "Gosho";
            p2.Age = 25;
            p3.Name = "Misho";
            p3.Age = 30;
        }
    }
}
